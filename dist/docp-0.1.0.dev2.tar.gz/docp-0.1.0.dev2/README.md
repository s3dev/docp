# A basic document parsing and loading utility.

Currently a **placeholder** for when this project is ready in the near future.

The ``docp`` project is a CPython library for extracting text from binary documents (e.g. PDF, DOCX, etc.) into Python objects, which can be used across various applications, ranging from simple plain-text extraction to loading the text into a Chroma database for LLM use.


## Installation
Coming soon ...


## Toolset
Coming soon ...


## Using the Library
Coming soon ...


## Additional Information
Coming soon ...

