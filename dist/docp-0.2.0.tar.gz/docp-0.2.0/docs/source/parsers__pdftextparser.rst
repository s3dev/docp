
================================================
Base (Private) Module: parsers/_pdftextparser.py
================================================

.. automodule:: docp.parsers._pdftextparser

