
=================================================
Base (Private) Module: parsers/_pptxtextparser.py
=================================================

.. automodule:: docp.parsers._pptxtextparser

