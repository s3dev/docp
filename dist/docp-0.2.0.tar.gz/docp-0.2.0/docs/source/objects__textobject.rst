
=============================================
Base (Private) Module: objects/_textobject.py
=============================================

.. automodule:: docp.objects._textobject

