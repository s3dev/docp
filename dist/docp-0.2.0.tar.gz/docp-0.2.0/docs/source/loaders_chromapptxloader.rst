
.. _module-loaders-chromapptxloader:

===================================
Module: loaders/chromapptxloader.py
===================================

.. automodule:: docp.loaders.chromapptxloader

