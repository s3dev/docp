
=============================================
Base (Private) Module: objects/_pageobject.py
=============================================

.. automodule:: docp.objects._pageobject

