
==============================================
Base (Private) Module: objects/_slideobject.py
==============================================

.. automodule:: docp.objects._slideobject

