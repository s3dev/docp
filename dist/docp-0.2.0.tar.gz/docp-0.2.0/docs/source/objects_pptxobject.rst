
=============================
Module: objects/pptxobject.py
=============================

.. automodule:: docp.objects.pptxobject

