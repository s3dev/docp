
=================================================
Base (Private) Module: parsers/_pptxbaseparser.py
=================================================

.. automodule:: docp.parsers._pptxbaseparser

