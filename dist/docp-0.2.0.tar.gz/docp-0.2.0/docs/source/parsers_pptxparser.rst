
=============================
Module: parsers/pptxparser.py
=============================

.. automodule:: docp.parsers.pptxparser

