
.. _module-loaders-chromapdfloader:

==================================
Module: loaders/chromapdfloader.py
==================================

.. automodule:: docp.loaders.chromapdfloader

